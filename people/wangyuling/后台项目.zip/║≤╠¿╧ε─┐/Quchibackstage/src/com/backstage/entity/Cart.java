package com.backstage.entity;

public class Cart {
	private int count;
	private FastFood fastfood;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public FastFood getFastfood() {
		return fastfood;
	}
	public void setFastfood(FastFood fastfood) {
		this.fastfood = fastfood;
	}
	
}
